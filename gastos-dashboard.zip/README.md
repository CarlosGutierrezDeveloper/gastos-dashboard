# 💰 Mis Gastos — Dashboard de Control de Gastos Personales

Dashboard interactivo para controlar gastos diarios, mensuales y anuales, con
cálculo automático de cashback (Rappi 1% + Banco de Bogotá 5%), comparativos
mes contra mes, análisis por comercio y una tabla detallada de movimientos.

Los datos se guardan en **Airtable** y se leen/escriben directamente desde el
navegador — sin backend, 100% desplegable en **GitHub Pages**.

---

## 1. Modelo de datos

### ¿Qué se guarda en Airtable y qué se calcula en el dashboard?

Para evitar datos duplicados o desincronizados, en Airtable **solo se guardan
los datos crudos de cada compra**. Todas las columnas derivadas (Año, Mes,
Mes-Año, cashback, etc.) se calculan en tiempo real dentro del dashboard a
partir de esos datos crudos — es la práctica recomendada (una sola fuente de
verdad).

### Tabla a crear en Airtable: `Gastos`

| Campo             | Tipo Airtable         | Notas                                                              |
|-------------------|------------------------|---------------------------------------------------------------------|
| `Fecha`           | Date                   | Sin hora. Cualquier formato de visualización sirve.                |
| `Comercio`        | Single line text       | Ej: "Éxito", "Rappi", "D1"                                         |
| `Descripcion`     | Single line text       | Opcional                                                           |
| `Valor`           | Number o Currency      | Monto de la compra (COP), sin fórmulas                            |
| `Categoria`       | Single select          | Se crea sola la primera vez que agregues un gasto (ver más abajo)  |
| `AplicaCashback`  | Checkbox               | Marcado por defecto. Desmárcalo para compras que no generan cashback |

> No necesitas crear las opciones de `Categoria` manualmente: la app usa
> `typecast: true` al escribir, así que Airtable las crea automáticamente
> la primera vez que uses cada categoría (Comida, Transporte, Entretenimiento,
> Compras, Servicios, Otros). Si quieres, puedes editarles el color en Airtable
> después — es solo cosmético dentro de Airtable, el dashboard usa sus propios
> colores.

### Columnas derivadas (calculadas por el dashboard, no se guardan)

`Año`, `Mes`, `Nombre del mes`, `Mes-Año`, `Día`, `Año-Mes` (llave de orden),
`Cashback Rappi`, `Cashback Banco de Bogotá`, `Cashback total`.

### Fórmulas de negocio implementadas

```
Cashback Rappi         = Valor * 0.01
Cashback Banco Bogotá  = Valor * 0.05
Cashback total          = Cashback Rappi + Cashback Banco Bogotá
Diferencia              = gasto mes anterior − gasto mes actual
                          (positivo = gastaste MENOS que el mes anterior)
Variación %             = Diferencia / gasto mes anterior
                          (si el mes anterior es 0, se muestra "—")
```

> 💡 **Opcional:** si quieres ver el cashback también dentro de la tabla de
> Airtable (no solo en el dashboard), puedes agregar 3 campos tipo *Formula*:
> `CashbackRappi = {Valor} * 0.01`, `CashbackBB = {Valor} * 0.05`,
> `CashbackTotal = {CashbackRappi} + {CashbackBB}`. Es puramente informativo;
> el dashboard no los necesita.

---

## 2. Crear la base de Airtable

1. Entra a [airtable.com](https://airtable.com) y crea una base nueva (puede
   estar vacía).
2. Renombra la tabla por defecto a **`Gastos`** (o el nombre que prefieras,
   solo debes usarlo igual en el paso 3).
3. Crea los campos de la tabla anterior con los tipos indicados.
4. Copia el **Base ID**: ábrela y mira la URL, se ve así:
   `https://airtable.com/appXXXXXXXXXXXXXX/...` → `appXXXXXXXXXXXXXX` es tu Base ID.

## 3. Crear tu Personal Access Token (PAT)

1. Ve a **[airtable.com/create/tokens](https://airtable.com/create/tokens)**.
2. Click en **Create token**.
3. Dale un nombre (ej: "Dashboard Gastos").
4. En **Scopes**, agrega:
   - `data.records:read`
   - `data.records:write`
5. En **Access**, selecciona la base que creaste en el paso 2.
6. Crea el token y **cópialo de inmediato** (no podrás verlo de nuevo).

> 🔒 **Importante sobre seguridad:** este token le da acceso a tu base de
> Airtable. La app lo pide una sola vez en el navegador y lo guarda **solo en
> el `localStorage` de tu dispositivo** — nunca queda escrito en el código ni
> se sube al repositorio. Como el sitio será público en GitHub Pages, cualquier
> persona que entre a la URL sin tu token no podrá ver ni modificar tus datos,
> pero sí vería la app vacía pidiendo configuración. Este enfoque es adecuado
> para uso personal; si algún día quieres compartir el dashboard con más
> personas de forma seguridad reforzada, la alternativa es poner el token
> detrás de un pequeño servidor (Cloudflare Worker / Vercel Function) en vez
> de en el navegador.

---

## 4. Probar el dashboard en tu computador (antes de publicarlo)

Como el proyecto usa módulos de JavaScript (`type="module"`), los navegadores
NO lo abren correctamente con doble clic (`file://`). Necesitas un servidor
local muy simple:

```bash
cd gastos-dashboard
python3 -m http.server 8000
```

Luego abre **http://localhost:8000** en tu navegador. La primera vez te pedirá
el Token, el Base ID y el nombre de la tabla — pega los datos de los pasos 2 y 3,
dale **"Probar conexión"** y luego **"Guardar y continuar"**.

(Alternativa sin Python: `npx serve .` si tienes Node instalado.)

---

## 5. Publicar en GitHub Pages (URL pública)

### Paso a paso

1. **Crea un repositorio en GitHub**
   - Entra a [github.com/new](https://github.com/new)
   - Nombre sugerido: `gastos-dashboard`
   - Puede ser público o privado (GitHub Pages funciona con ambos si tienes
     plan Pro; con cuenta gratuita debe ser público para tener Pages).
   - No agregues README ni .gitignore desde la web (ya vienen en el proyecto).

2. **Sube el código** (desde la carpeta del proyecto):
   ```bash
   cd gastos-dashboard
   git init
   git add .
   git commit -m "Dashboard de gastos personales"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/gastos-dashboard.git
   git push -u origin main
   ```

3. **Activa GitHub Pages**
   - Ve a tu repositorio en GitHub → **Settings** → **Pages** (menú izquierdo).
   - En **Source**, selecciona **Deploy from a branch**.
   - En **Branch**, selecciona **main** y carpeta **/ (root)** → **Save**.

4. **Espera 1-2 minutos** y GitHub te mostrará la URL pública, con este formato:
   ```
   https://TU_USUARIO.github.io/gastos-dashboard/
   ```

5. Abre esa URL desde cualquier dispositivo (celular, otro computador, etc.),
   ingresa tu configuración de Airtable la primera vez que entres desde cada
   dispositivo/navegador (el `localStorage` es local a cada navegador) y ¡listo!

### Actualizaciones futuras

Cada vez que quieras modificar el dashboard:
```bash
git add .
git commit -m "Descripción del cambio"
git push
```
GitHub Pages se actualiza automáticamente en 1-2 minutos.

---

## 6. Estructura del proyecto

```
gastos-dashboard/
├── index.html          # Estructura de la página
├── css/
│   └── style.css        # Tema oscuro, colores y responsive
├── js/
│   ├── config.js         # Guarda/lee credenciales en localStorage
│   ├── airtable.js        # CRUD contra la API REST de Airtable
│   ├── calculations.js    # Cashback, KPIs, comparativos, agrupaciones
│   ├── charts.js           # Gráficas (Chart.js vía CDN)
│   ├── ui.js                # Renderizado, filtros, modales
│   └── main.js                # Punto de entrada
└── README.md
```

## 7. Funcionalidades incluidas

- ✅ KPIs de cabecera (gasto mes actual/anterior, diferencia, variación %,
  cashback por banco, cashback acumulado histórico, ticket promedio)
- ✅ Evolución temporal: gasto diario, cashback acumulado (con selector
  Día/Mes/Año), comparativo mensual y anual
- ✅ Análisis por comercio: Top N, participación (donut), tabla detalle
- ✅ Consulta interactiva por mes y año específico, comparado automáticamente
  contra el mes anterior a ese
- ✅ Tabla de movimientos con orden por columnas, edición y eliminación
- ✅ Filtros globales: año, mes, rango de fechas, comercio, categoría,
  importe mínimo/máximo, Top N
- ✅ Exportar a CSV
- ✅ Formulario de "Agregar Gasto" con selector de categoría con colores
- ✅ Responsive (se adapta a celular)

## 8. Próximas mejoras posibles (no incluidas)

- Autenticación multiusuario (hoy es de un solo usuario/token)
- Presupuestos por categoría con alertas
- Modo claro/oscuro alternable
- Gráfico de gasto por categoría (actualmente el análisis es por comercio)
